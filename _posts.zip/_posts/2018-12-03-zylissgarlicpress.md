---
title:  "Zyliss Susi 3 Garlic Press, Red, Stainless steel"
brand: "Zyliss"
thumbnailurl: "https://ws-eu.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B006MST90G&Format=_SL160_&ID=AsinImage&MarketPlace=GB&ServiceVersion=20070822&WS=1&tag=codemartin04-21&language=en_GB"
tags: [garlic press,garlic crusher]
author: Martin Dye
description: "I would say that you do need to use some force with this one, especially if you are crushing two cloves of garlic at once."
categories: [Homeware]
rating: 4.5
price: "15.49"
sku: "Not Available"
mpn: "E12150"
---

This is another fantastic bit of kitchen kit that saves me time. There's no need to peel the garlic (in fact, you'll find
it doesn't work as well if you peel the garlic first). The garlic is crushed and squeezed through
the small holes leaving the skin behind. I've used other brands of garlic press and they simply don't do the job as well.
This one is very efficient and at a guess I'd say it pushes 90-95% of the garlic through the holes. Models from other
manufacturers are just not worth it, and you'll find they leave 25-50% of the garlic behind, being mushed up the edge on the inside.
This model has been improved - it still works as well as the previous model but it now has a special cleaning tool which can
be ejected by pushing the little red button. The tool has an array of plastic pins on one end, for cleaning the garlic from the
holes (rotate 180 degrees first) and some spikes on the other end for scooping out the garlic skin. Yes, you can use your
nails, but with this tool your fingers won't be smelling of garlic for the few hours.

<iframe width="560" height="315" src="https://www.youtube.com/embed/0KCwkkW80U8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<h4><em>Conclusion</em></h4>

I would say that you do need to use some force with this one, especially if you are crushing two cloves of garlic
at once. If you can't squeeze firmly enough, a press with longer handles may be more effective.
I'm so impressed with this that I think inventor's face should be featured on the back of the next £5 note.
Seriously though, it's really the only garlic press you need. I also think it produces a better quality crushed garlic
compared to smashing with the side of the knife and / or finely chopping it.

https://www.amazon.co.uk/Zyliss-Garlic-Press-Stainless-steel/dp/B006MST90G?crid=6WQT3VQNH34E&dib=eyJ2IjoiMSJ9.s-eLE8aEk4WfNNpF4EidarfzVdoehyWXxitSZgcFdb3XFxRU67bzO043oCFV6NwptQT-T7MibFr9odkCzTf3fTfg3nZ5c2quM1mnbmPiKW6avRR_JcTlfPMpLGG5xRvFvDZQ5gN3t1fAENG7TMCVBBtH75YjCEcpMZNOROz0fdPnXOD6DcvoKnsln1sTsJwQIV_T5eoDGJEzOCDp6gr-J692sYA5C_MpowSp9zZZdRnC8XSOr6MwvofrQsbamWjSwaLjE-jGNo0FMxdKVNbilq5dUtnfZu3rx-i9fyt6S5I.gofWR1fwHqxarINFh1c5tUBGvBweiVFPDu_wWVsG2_g&dib_tag=se&keywords=Zyliss+Susi+3+Garlic+Press%2C+Red%2C+Stainless+steel&qid=1721499410&sprefix=zyliss+susi+3+garlic+press+red+stainless+steel%2Caps%2C91&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1&linkCode=ll1&tag={{site.affid}}&linkId=72171217a84dd866881275fe3e545fd9&language=en_GB&ref_=as_li_ss_tl
	
{% comment %}
{% endcomment %}