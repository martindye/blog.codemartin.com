---
title:  "Green Tea Lotus by Elizabeth Arden - EDT 100ml"
brand: "Elizabeth Arden"
thumbnailurl: "https://ws-eu.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B0028VM7CI&Format=_SL160_&ID=AsinImage&MarketPlace=GB&ServiceVersion=20070822&WS=1&tag=codemartin04-21&language=en_GB"
categories: [Perfume]
tags: [perfume scent]
author: Doina Fatu
description: "Green Tea by Arden is an affordable everyday perfume with a clean, citrucy smell and it's worth it as you can reapply, the bottle is big enough."
rating: 4
price: "19.01"
sku: "Not Available"
mpn: "I0033651"
---

The perfume still has the same nice clean fresh smell, I was pleased to discover they didn't change that
citrucy lemon balm scent which I love; that's why bought this perfume a few times till now. It's very light and fresh,
so nothing to dislike in it, not heavy and it's perfect for every day wear. The smell lasts a while but not a whole day 
as it's a discreet perfume and the lingering will vary from person to person as most perfumes do as pH of the skin is 
different. On my skin lasts a few hours and its a very pleasant smell, not too sweet just right. If this perfume would 
have lasted a whole day or more as I know a perfume from another brand that has an incredible longevity on me but of
course much much more expensive and its suitable only for evening wear or cold weather as in heat, it can give me
migraines.

<h4><em>Conclusion</em></h4>

Green Tea by Arden is an affordable everyday perfume with a clean, citrucy smell and it's worth it
as you can reapply, the bottle is big enough. Much better choice than other perfumes or eau de toilette that you can't
wear as they are sickly sweet or they have a heavy weird scent.

https://www.amazon.co.uk/Elizabeth-Arden-Green-Lotus-Toilette/dp/B006AAL36Y?crid=2C2726UHJ82I8&dib=eyJ2IjoiMSJ9.3qiwctLpHs0FsO480HGa9CLalzqb69_BRJU14ThXHq3-yqCjyscSSWLoalu1qsUmiXDp_VJC1tpZAxcPF1orkikpYqIuveh22U--p1N_xGG54avA5FPKF64-8RePJmDZbzD9zBnd_HNwFb6jkw1rZRMwokuWrhvG44mn6XQTCXR5lnk7INxQ6gmxe6wwzEaIi34_UAatPLzg-plB5Ggaq1hmth1jNwccq8hkvrAZ5nbjAb3jr9UUrL-SgVtFonDx1_FnwZFg5eZAjQlpw9b-4IdO78RU4yneUjzyT37LP1c.CKHiQXJB5DYwvKk-XSwOFZmyCzCYSIPPThen7RC6DLQ&dib_tag=se&keywords=Green+Tea+Lotus+by+Elizabeth+Arden+-+EDT+100ml&qid=1721499445&sprefix=green+tea+lotus+by+elizabeth+arden+-+edt+100ml%2Caps%2C86&sr=8-1&linkCode=ll1&tag={{site.affid}}&linkId=0cadb9c484154c8e7fb1195a33e148de&language=en_GB&ref_=as_li_ss_tl
{% comment %}

Link only
{% endcomment %}