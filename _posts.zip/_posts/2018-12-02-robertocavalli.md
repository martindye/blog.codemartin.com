---
title:  "Roberto Cavalli Perfume for Women Eau de Parfum - 50 ml"
brand: "Roberto Cavalli"
thumbnailurl: "https://ws-eu.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B006MPZPVQ&Format=_SL160_&ID=AsinImage&MarketPlace=GB&ServiceVersion=20070822&WS=1&tag=codemartin04-21&language=en_GB"
categories: [Perfume]
tags: [perfume scent]
author: Doina Fatu
description: "Roberto Cavalli for Women Eau de Parfum - 50 ml Review"
rating: 5
price: "37.30"
sku: "Not Available"
mpn: "10000378"
---

One of my favourite frangrances during time and tried a few already as im over 40.
I bought it in 2010 for the first time and was happy to buy it again and meet the same scent.
Wonderful, mesmerising strong enough but not too strong, just perfect in my opinion. 
It's slightly sweet but just with a hint of lovely vanilla, however I wouldn't consider it a sweet perfume,
I would say its a powdery one, with a long staying power that sticks very well on my skin and lingers throughout the day,
even in the shower I feel it on my skin. It's so lovely that I don't mind the refined, complex aroma as its a feminine, 
sexy scent more suitable for evening wear but during day time is nice as well as it's more powdery, which stays more 
on your skin than the clothes, so that's why I like it. You can build it up if you wish for a stronger smell 
but a few drops around the neck or pulse points will do as its staying power is very good. 
Its a refined perfume, very feminine hence 5 stars from me.

<h4><em>Conclusion</em></h4>
It has a refined, complex aromatic powdery scent, more suitable for evening wear but during daytime will do 
if you don't apply too much as it's pretty strong. It smells pretty similar to the big bottle of 75 ml I bought in 2010.
Very good value as its a lovely scent with pretty long staying power, powdery which sticks well on the skin.
It might not be for everybody as its a slightly sweet powdery scent, if you love fresh scents maybe its not the right one 
for you but more that 70 per cent of women will like it for evening wear.

https://www.amazon.co.uk/Roberto-Cavalli-Perfume-Spray-50ml/dp/B00F645X7U?crid=RRYPCY64RHFL&dib=eyJ2IjoiMSJ9.Sj_iuBNq9Knm1RrIRh7nPQMCib9_xfLfE8hz4hW6sOqhZehp-F4eWUaGHN3CkG5XDRZF4LsjKB1RZvTHGH50a9V41sI-u6zaELvBUNASMl8ERrl3fOp466ld9RTE0qlRyJ4f49y4Cy05kHNTTxQ1ykYuuRXhtLqXqICaQ-75-l8g0kDvAXfhP4gV0O8hfKTnuimY9Wo-rBlvOay3Jv2EG1JSL7iKwdZ2Wq2DPyejrfQqN3PHCt3enBtBXLM4DYLBo0yCdxoFF7F2GKO8LUq-J73YoxQAS9QeUSsS9PhcBCE.wqkn-KGRp0Z4eh7uzj1Txl-vAq_Ro671MvL562V7QJo&dib_tag=se&keywords=Roberto+Cavalli+Perfume+for+Women+Eau+de+Parfum+-+50+ml&qid=1721498911&sprefix=roberto+cavalli+perfume+for+women+eau+de+parfum+-+50+ml%2Caps%2C86&sr=8-5&linkCode=ll1&tag={{site.affid}}&linkId=b286ff58c1affc4c3d0e4a44e7a12fc3&language=en_GB&ref_=as_li_ss_tl

{% comment %}

Link only

{% endcomment %}