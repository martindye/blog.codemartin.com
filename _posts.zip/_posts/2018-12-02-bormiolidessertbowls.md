---
title:  "Bormioli Rocco Dessert Bowls Ypsilon 4pcs 37.5cl"
brand: "Bormioli Rocco"
thumbnailurl: "/assets/mousseauchocolat.jpg"
tags: [amazon echo]
author: Doina Fatu
description: "Really nice shape and design. They look fabulous when loaded even with desserts that don't look so elegant when seated on a plate, such as apple crumble."
categories: [Homeware]
rating: 5
price: "18.99"
sku: "Not Available"
mpn: "BO-340750"
---

Really nice shape and design. They look fabulous when loaded even with desserts that don't look so elegant when seated on a plate, such as apple crumble.

I've used these dessert glasses every 2 days or so for home made trifle or mousse au chocolat. Easy to wash too.

![Mousse au chocolat](/assets/mousseauchocolat.jpg)
<h6>This mousse au chocolat was for two people to share or one greedy person. It's 2-3 times bigger than a Gü Chocolate Mousse.</h6>

<h4><em>Conclusion</em></h4>

It's a very good value for money as its a nice glass, plenty big enough.
For the money you can't find better in a high street store as it will be at least £20.

<em>
Note, since this review, the bowls are now sold as a set of 6, so they're still great value for money!
</em>

https://www.amazon.co.uk/Bormioli-Rocco-Universal-Dessert-Bowl/dp/B002IT6WO4?crid=2TI3NZKJ8TF01&dib=eyJ2IjoiMSJ9.9sVnrcE2Nepa1lCTzMDDVf2XNdYGUcchGA2d5hU54K3jpz6z-ynT04Qp_Wtncjz44enJEpO7jJaK5w2zIqpxNm9-N9EAyP-TmjnEwqsGc9mouyT8NJSXI5Y6ui_ounnFV2wxmma4PzGhTTTG3fLCdtSCSnZWorqe2fxb655osG36W1x0h6M6rGTG49v3aZ_Naksa2IC-WvdbS2SL3dZWg91drTpGr3NGJYEGtvxUfpvBr706r8J90hf3A-k1eMPWITRsSoTIkn0dtG4KyXjaz33O0ZHWQHan3zWlieUHtj0.YdRY0TPDIwrqFlnVE-lzxiReV5H3I_zqitF9bTmLs80&dib_tag=se&keywords=Bormioli+Rocco+Dessert+Bowls&qid=1721498735&sprefix=bormioli+rocco+dessert+bowls%2Caps%2C94&sr=8-37&linkCode=ll1&tag={{site.affid}}&linkId=c2d4b41329e6f1f824f3c6d3cad39982&language=en_GB&ref_=as_li_ss_tl

{% comment %}

Link only

{% endcomment %}